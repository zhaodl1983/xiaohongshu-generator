#!/usr/bin/env python3
"""测试动态幻灯片数量功能"""

from main import calculate_slide_count

# 测试不同长度的内容
test_cases = [
    (1000, "短文"),
    (1500, "中短文"),
    (2500, "中等长度"),
    (3500, "较长文章"),
    (4500, "长文"),
]

print("📊 动态幻灯片数量测试\n")
print("字数范围 → 内容页数量 → 总图片数（含封面）")
print("-" * 50)

for char_count, desc in test_cases:
    slide_count = calculate_slide_count("x" * char_count)
    total = slide_count + 1
    print(f"{char_count:5d} 字 ({desc:8s}) → {slide_count} 张内容页 → {total} 张图片")

print("\n规则说明：")
print("• < 1500 字：5 张内容页（总共 6 张）")
print("• 1500-2499 字：6 张内容页（总共 7 张）")
print("• 2500-3499 字：7 张内容页（总共 8 张）")
print("• ≥ 3500 字：8 张内容页（总共 9 张，最大值）")
