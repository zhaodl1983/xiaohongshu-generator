#!/usr/bin/env python3
"""测试 Gemini API 是否可用"""

import google.generativeai as genai
import config

print("🔍 测试 Gemini API 连接...\n")

try:
    # 配置 API
    genai.configure(api_key=config.GEMINI_API_KEY)
    
    # 创建模型
    model = genai.GenerativeModel(config.MODEL_NAME)
    
    # 发送简单测试请求
    print(f"📡 使用模型: {config.MODEL_NAME}")
    print("💬 发送测试消息: '你好，请用一句话介绍自己'\n")
    
    response = model.generate_content("你好，请用一句话介绍自己")
    
    print("✅ API 调用成功！")
    print(f"📝 响应内容: {response.text}\n")
    print("🎉 Gemini API 工作正常，可以运行 main.py 了！")
    
except Exception as e:
    print(f"❌ API 调用失败")
    print(f"错误信息: {str(e)}\n")
    
    if "quota" in str(e).lower() or "429" in str(e):
        print("💡 原因: API 配额已用完")
        print("   解决方案:")
        print("   1. 等待配额重置（通常每天重置）")
        print("   2. 检查 https://aistudio.google.com/apikey 的使用情况")
        print("   3. 或使用 test_without_api.py 测试功能")
    elif "404" in str(e) or "not found" in str(e).lower():
        print("💡 原因: 模型名称不正确或不可用")
        print("   解决方案:")
        print("   1. 尝试修改 config.py 中的 MODEL_NAME")
        print("   2. 可选值: 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-pro'")
    else:
        print("💡 请检查:")
        print("   1. API Key 是否正确")
        print("   2. 网络连接是否正常")
