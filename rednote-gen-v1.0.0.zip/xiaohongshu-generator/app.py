#!/usr/bin/env python3
"""
小红书图文生成工具 - Web 版本
Flask 后端服务
"""

import json
import asyncio
import base64
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file
import zipfile
import io

from main import summarize_to_slides, render_html, capture_slides

app = Flask(__name__)

@app.route('/')
def index():
    """主页"""
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    """生成图片 API"""
    try:
        data = request.json
        content = data.get('content', '')
        style = data.get('style', 'xiaohongshu')  # 预留风格参数
        
        if not content or len(content.strip()) < 50:
            return jsonify({'error': '内容太短，请输入至少 50 字'}), 400
        
        print(f"🤖 调用 AI 生成内容 (风格: {style})")
        
        # 调用 AI 生成幻灯片内容
        slides_data = summarize_to_slides(content)
        
        # 渲染 HTML（传递风格参数）
        html_content = render_html(slides_data, style)
        
        # 截图生成图片
        output_files = asyncio.run(capture_slides(html_content))
        
        # 读取图片并转为 base64
        images = []
        for filepath in output_files:
            with open(filepath, 'rb') as f:
                img_data = base64.b64encode(f.read()).decode('utf-8')
                images.append({
                    'filename': Path(filepath).name,
                    'data': f'data:image/png;base64,{img_data}'
                })
        
        return jsonify({
            'success': True,
            'slides_data': slides_data,
            'images': images,
            'count': len(images)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/regenerate-style', methods=['POST'])
def regenerate_style():
    """使用已有的 JSON 数据重新生成不同风格的图片"""
    try:
        data = request.json
        slides_data = data.get('slides_data')
        style = data.get('style', 'xiaohongshu')
        
        if not slides_data:
            return jsonify({'error': '缺少幻灯片数据'}), 400
        
        print(f"🎨 切换风格到: {style} (不调用 AI，使用已有数据)")
        
        # 使用已有数据渲染新风格的 HTML
        html_content = render_html(slides_data, style)
        
        # 截图生成图片
        output_files = asyncio.run(capture_slides(html_content))
        
        # 读取图片并转为 base64
        images = []
        for filepath in output_files:
            with open(filepath, 'rb') as f:
                img_data = base64.b64encode(f.read()).decode('utf-8')
                images.append({
                    'filename': Path(filepath).name,
                    'data': f'data:image/png;base64,{img_data}'
                })
        
        return jsonify({
            'success': True,
            'images': images,
            'count': len(images)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/download/<filename>')
def download(filename):
    """下载单张图片"""
    filepath = Path('output') / filename
    if filepath.exists():
        return send_file(filepath, as_attachment=True)
    return jsonify({'error': '文件不存在'}), 404

@app.route('/download-all')
def download_all():
    """下载所有图片（ZIP）"""
    output_dir = Path('output')
    png_files = list(output_dir.glob('slide_*.png'))
    
    if not png_files:
        return jsonify({'error': '没有可下载的图片'}), 404
    
    # 创建 ZIP 文件
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for filepath in sorted(png_files):
            zf.write(filepath, filepath.name)
    
    zip_buffer.seek(0)
    return send_file(
        zip_buffer,
        mimetype='application/zip',
        as_attachment=True,
        download_name='xiaohongshu_slides.zip'
    )

if __name__ == '__main__':
    Path('output').mkdir(exist_ok=True)
    app.run(debug=True, port=5000)
