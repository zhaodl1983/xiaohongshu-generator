#!/usr/bin/env python3
"""测试 AI 对不同内容的图片数量决策"""

import asyncio
from main import read_input_file, summarize_to_slides

def test_content(filepath: str, description: str):
    """测试单个文件"""
    print(f"\n{'='*60}")
    print(f"测试: {description}")
    print(f"文件: {filepath}")
    print('='*60)
    
    try:
        # 读取文件
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        char_count = len(content)
        print(f"📝 文章长度: {char_count} 字")
        
        # 调用 AI
        print("🤖 AI 分析中...")
        result = summarize_to_slides(content)
        
        slide_count = len(result['slides'])
        total = slide_count + 1
        
        print(f"✅ AI 决定生成: {total} 张图片（1 封面 + {slide_count} 内容页）")
        print(f"📌 封面标题: {result['cover_title']}")
        print(f"📊 平均每页要点数: {sum(len(s['content']) for s in result['slides']) / slide_count:.1f}")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")

if __name__ == "__main__":
    print("🧪 AI 图片数量决策测试")
    print("测试 AI 如何根据不同内容自主决定图片数量\n")
    
    # 测试短文
    test_content("test_short_content.txt", "短文测试（约 380 字）")
    
    # 测试长文
    test_content("input.txt", "长文测试（约 4000 字）")
    
    print("\n" + "="*60)
    print("✅ 测试完成！")
    print("观察：AI 会根据内容的信息密度和结构自主决定图片数量")
