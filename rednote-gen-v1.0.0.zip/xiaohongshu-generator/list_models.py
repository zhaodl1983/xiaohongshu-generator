#!/usr/bin/env python3
"""列出所有可用的 Gemini 模型"""

import google.generativeai as genai
import config

print("🔍 查询可用的 Gemini 模型...\n")

try:
    genai.configure(api_key=config.GEMINI_API_KEY)
    
    print("可用模型列表：\n")
    for model in genai.list_models():
        if 'generateContent' in model.supported_generation_methods:
            print(f"✅ {model.name}")
            print(f"   显示名称: {model.display_name}")
            print(f"   支持方法: {', '.join(model.supported_generation_methods)}")
            print()
    
except Exception as e:
    print(f"❌ 查询失败: {e}")
