#!/usr/bin/env python3
"""
测试版本：不调用 API，使用模拟数据测试 HTML 渲染和截图功能
"""

import json
import asyncio
from pathlib import Path

from jinja2 import Environment, FileSystemLoader
from playwright.async_api import async_playwright


def get_mock_slides_data() -> dict:
    """返回模拟的幻灯片数据"""
    return {
        "cover_title": "高效工作指南",
        "cover_subtitle": "从时间管理到深度工作的完整方法论",
        "slides": [
            {
                "title": "什么是真正的高效",
                "content": [
                    "高效不是工作16小时，而是有限时间内产出最大价值",
                    "学会区分重要和紧急的事情",
                    "80%精力投入重要但不紧急的事"
                ]
            },
            {
                "title": "时间管理第一步",
                "content": [
                    "每天早上列出3-5件最重要的事",
                    "使用番茄工作法：25分钟专注+5分钟休息",
                    "人的注意力只能持续25-45分钟"
                ]
            },
            {
                "title": "深度工作的力量",
                "content": [
                    "创造大块不被打扰的时间",
                    "每天至少2-3小时深度工作",
                    "关闭所有通知，全身心投入重要任务"
                ]
            },
            {
                "title": "选对工具事半功倍",
                "content": [
                    "任务管理：Todoist 或 Things",
                    "笔记管理：Notion 或 Obsidian",
                    "时间追踪：RescueTime"
                ]
            },
            {
                "title": "身体是革命本钱",
                "content": [
                    "保证每天7-8小时睡眠",
                    "每周至少3次30分钟有氧运动",
                    "健康饮食：多吃蔬果和优质蛋白"
                ]
            }
        ]
    }


def render_html(slides_data: dict) -> str:
    """使用 Jinja2 渲染 HTML 模板"""
    env = Environment(loader=FileSystemLoader("."))
    template = env.get_template("template.html")
    return template.render(**slides_data)


async def capture_slides(html_content: str, output_dir: str = "output") -> list[str]:
    """使用 Playwright 截图每张卡片"""
    Path(output_dir).mkdir(exist_ok=True)

    temp_html = Path("_temp_render.html")
    temp_html.write_text(html_content, encoding="utf-8")

    output_files = []

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(
            viewport={"width": 1600, "height": 2000},
            device_scale_factor=2,
        )

        await page.goto(f"file://{temp_html.absolute()}")
        await page.wait_for_load_state("networkidle")

        card_index = 1
        while True:
            card = page.locator(f"#card-{card_index}")
            if await card.count() == 0:
                break

            output_path = f"{output_dir}/slide_{card_index}.png"
            await card.screenshot(path=output_path)
            output_files.append(output_path)
            print(f"✅ 已生成: {output_path}")
            card_index += 1

        await browser.close()

    temp_html.unlink()
    return output_files


async def main():
    """主流程"""
    print("🎨 使用模拟数据测试（不调用 API）\n")

    print("📝 生成模拟幻灯片数据...")
    slides_data = get_mock_slides_data()
    print(f"   封面标题: {slides_data['cover_title']}")
    print(f"   幻灯片数: {len(slides_data['slides'])} 张")

    # 保存 JSON
    Path("output").mkdir(exist_ok=True)
    with open("output/slides_data.json", "w", encoding="utf-8") as f:
        json.dump(slides_data, f, ensure_ascii=False, indent=2)
    print("\n💾 JSON 数据已保存到 output/slides_data.json")

    print("\n🎨 渲染 HTML 模板...")
    html_content = render_html(slides_data)

    print("\n📸 使用 Playwright 截图...")
    output_files = await capture_slides(html_content)

    print(f"\n🎉 完成！共生成 {len(output_files)} 张图片")
    print("   输出目录: output/")
    print("\n💡 提示：这是测试版本，使用的是模拟数据")
    print("   配置好 API 后，运行 main.py 即可使用真实 AI 生成内容")


if __name__ == "__main__":
    asyncio.run(main())
